import "./App.css";
import Login from "./Component/login";
import Listing from "./Component/Listing";
import Clientform from "./Component/Clientform";
import Sidebar from "./Component/Sidebar";
import { Routes, Route } from "react-router-dom";
import { PrivaterouteProvider } from "./Privateroute";

function App() {
  return (
    <div>
      <PrivaterouteProvider>
        <Routes>
          <Route path="/" element={<Login />} />

          <Route path="client-listing" element={<Listing />} />
          <Route path="client-Form" element={<Clientform />} />
          <Route path="sidebar" element={<Sidebar />} />
        </Routes>
      </PrivaterouteProvider>
    </div>
  );
}

export default App;
