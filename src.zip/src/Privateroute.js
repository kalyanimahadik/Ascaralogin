import { useState, createContext, useContext } from "react";

const Privateroutecontext = createContext(null);

export const PrivaterouteProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  const login = (user) => {
    setUser(user);
  };
  const logout = () => {
    setUser(null);
  };
  return (
    <Privateroutecontext.Provider value={{ user, login, logout }}>
      {children}
    </Privateroutecontext.Provider>
  );
};

export const useAuth = () => {
  return useContext(Privateroutecontext);
};
