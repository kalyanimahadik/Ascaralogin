const login = (usr, pass) => {
  return fetch(
    `http://work.8848digitalerp.com/api/method/work.api.login.get_access_api_token?usr=${usr}&pwd=${pass}`,
    { method: "post" }
  );
};
const clientList = () => {
  const { token } = JSON.parse(localStorage.getItem("user"));
  return fetch("http://work.8848digitalerp.com/api/resource/Client", {
    method: "GET",
    headers: { Authorization: token },
  });
};
const clientForm = (data) => {
  const { token } = JSON.parse(localStorage.getItem("user"));

  return fetch(
    "http://work.8848digitalerp.com/api/resource/Client/Preston E Ford",
    {
      method: "PUT",
      headers: { Authorization: token },
      body: JSON.stringify(data),
    }
  );
};
const api = {
  login: login,
  clientList: clientList,
  clientForm: clientForm,
};
export default api;
