import React from "react";
import "@trendmicro/react-sidenav/dist/react-sidenav.css";

import SideNav, { NavItem, NavIcon, NavText } from "@trendmicro/react-sidenav";
import "../assets/sidebar.css";
const Sidebar = () => {
  return (
    <>
      <SideNav
        expanded={true}
        style={{ background: "blue", position: "fixed" }}
      >
        <SideNav.Nav>
          <NavItem eventKey="home">
            <NavIcon>
              <i className="fa fa-fw fa-home" style={{ fontSize: "1.75em" }} />
            </NavIcon>
          </NavItem>
        </SideNav.Nav>

        <SideNav.Nav>
          <NavItem eventKey="home">
            <NavIcon>
              <i className="fa fa-fw fa-home" style={{ fontSize: "1.75em" }} />
            </NavIcon>
            <NavText>
              <a className="pathchange" href="/client-listing">
                Listing
              </a>
            </NavText>
          </NavItem>
        </SideNav.Nav>
      </SideNav>
    </>
  );
};

export default Sidebar;
