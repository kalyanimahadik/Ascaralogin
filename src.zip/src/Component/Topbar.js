import React from "react";
import { Navbar, Nav } from "react-bootstrap";
import "../assets/login.css";
import { Link } from "react-router-dom";
import "../assets/sidebar.css";
const Topbar = () => {
  return (
    <div className="mb-4">
      {" "}
      <Navbar bg="light">
        <Nav className="me-auto"></Nav>
        <Nav>
          <Link to="/" className="pathchange">
            <Navbar.Brand className="topbar" eventKey={2} href="#memes">
              Logout
            </Navbar.Brand>
          </Link>
        </Nav>
      </Navbar>
    </div>
  );
};

export default Topbar;
