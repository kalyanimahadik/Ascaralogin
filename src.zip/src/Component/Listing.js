import React, { useEffect, useState } from "react";
import Topbar from "./Topbar";
import { Button, Table } from "react-bootstrap";
import api from "../api";
import Sidebar from "./Sidebar";

import { Link } from "react-router-dom";

const Listing = () => {
  const [list, setList] = useState([]);
  useEffect(() => {
    api
      .clientList()
      .then((respo) => respo.json())
      .then((result) => {
        console.log(result);
        setList(result.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);
  console.log("list", list);
  const namelist = [];
  for (let value of list) {
    namelist.push(value.name);
  }
  console.log(namelist);
  return (
    <div>
      <Topbar />
      <Sidebar />
      <div
        className="container_main"
        style={{
          display: "flex",
          flexDirection: "row-reverse",
          marginTop: "100px",
        }}
      >
        <Link to="/client-form">
          <Button variant="primary" className="add-btn">
            Add Client
          </Button>
        </Link>
      </div>
      <div className="container_main">
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>ID</th>
              <th> Name</th>
            </tr>
          </thead>
          <tbody>
            {namelist.map((item, index) => {
              console.log(item);
              return (
                <>
                  <tr>
                    <td>{index}</td>
                    <td>{item}</td>
                  </tr>
                </>
              );
            })}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default Listing;
