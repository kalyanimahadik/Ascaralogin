import React, { useState } from "react";
import { Card, Button, Form } from "react-bootstrap";
import api from "../api";
import "../assets/login.css";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const Login = () => {
  const [validated, setValidated] = useState(false);
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");

  const navigate = useNavigate();
  const handleSubmit = (event) => {
    const form = event.currentTarget;
    event.preventDefault();
    if (form.checkValidity() === false) {
      event.stopPropagation();
    } else {
      console.log(email, pass);
      api
        .login(email, pass)
        .then((respo) => respo.json())
        .then((result) => {
          console.log(result.message);
          if (result.message.access_token != null) {
            const user = {
              token: result.message.access_token,
              email: result.message.email,
            };
            window.localStorage.setItem("user", JSON.stringify(user));

            toast("Login successfull");
            setTimeout(() => {
              navigate("/client-listing");
            }, 3000);
          } else {
            toast("Incorrect Username and Password");
          }
        })
        .catch((error) => {
          console.log(error);
        });
    }
    setValidated(true);
  };

  return (
    <>
      <div className="container">
        <Card className="login_main">
          <Card.Body>
            <Card.Title>Login Demo</Card.Title>

            <hr className="mb-4" />
            <Card.Title className="mb-3">Welcome</Card.Title>
            <Form noValidate validated={validated} onSubmit={handleSubmit}>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Email</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <Form.Control.Feedback type="invalid">
                  Please provide a valid email.
                </Form.Control.Feedback>
              </Form.Group>

              <Form.Group className="mb-4" controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Enter Password"
                  value={pass}
                  onChange={(e) => setPass(e.target.value)}
                  required
                />
                <Form.Control.Feedback type="invalid">
                  Please provide a password.
                </Form.Control.Feedback>
              </Form.Group>

              <Button className="login-btn" variant="primary" type="submit">
                Submit
              </Button>
              <ToastContainer />
            </Form>
          </Card.Body>
        </Card>
      </div>
    </>
  );
};
export default Login;
