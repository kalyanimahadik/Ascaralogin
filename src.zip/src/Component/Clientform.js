import React, { useState } from "react";
import { Form, Row, Col, Button } from "react-bootstrap";
import Topbar from "./Topbar";
import Sidebar from "./Sidebar";
import api from "../api";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Clientform = () => {
  const [validated, setValidated] = useState(false);
  const [representCompany, setRepresentCompany] = useState("");
  const [email, setEmail] = useState("");
  const [fullname, setFullname] = useState("");
  const [gender, setGender] = useState("");
  const [address, setAddress] = useState("");
  const [mob, setMob] = useState("");
  const [bank, setBank] = useState("");
  const [type, setType] = useState("");
  const [territory, setTerritory] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    const form = event.currentTarget;
    event.preventDefault();
    if (form.checkValidity() === false) {
      event.stopPropagation();
    } else {
      let data = {
        represents_company: representCompany,
        customer_name: fullname,
        email: email,
        gender: gender,
        address: address,
        mobile_no: mob,
        bank: bank,
        customer_type: type,
        territory: territory,
      };
      console.log(data);
      api
        .clientForm(data)
        .then((respo) => respo.json())
        .then((result) => {
          console.log("data", result);
          toast("Client Added Successfully");
          setTimeout(() => {
            navigate("/client-listing", { replace: true });
          }, 3000);
        })
        .catch((error) => {
          toast("Something Went Wrong");
          console.log(error);
        });
    }
    setValidated(true);
  };
  return (
    <>
      {" "}
      <Topbar />
      <Sidebar />
      <div className="container_main">
        <h4 className="mb-4 text-center">Client Form</h4>
        <Form noValidate validated={validated} onSubmit={handleSubmit}>
          <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
            <Form.Label column sm="2">
              Represents Company
            </Form.Label>
            <Col sm="10">
              <Form.Select
                aria-label="Default select example"
                value={representCompany}
                onChange={(e) => {
                  setRepresentCompany(e.target.value);
                }}
                required
              >
                <option>Select option</option>
                <option value="8848 Digital LLP">8848 Digital LLP</option>
                <option value="Wayne Enterprises">Wayne Enterprises</option>
                <option value="Showbiz Pizz Place">Showbiz Pizz Place</option>
                <option value="Pro Garden Management">
                  Pro Garden Management
                </option>
                <option value="The Lawn Guru">The Lawn Guru</option>
              </Form.Select>
            </Col>
          </Form.Group>
          <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
            <Form.Label column sm="2">
              Email
            </Form.Label>
            <Col sm="10">
              <Form.Control
                type="email"
                placeholder="email@example.com"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
                required
              />
            </Col>
            <Form.Control.Feedback type="invalid">
              Please provide a valid email.
            </Form.Control.Feedback>
          </Form.Group>
          <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
            <Form.Label column sm="2">
              Full Name
            </Form.Label>
            <Col sm="10">
              <Form.Control
                type="text"
                placeholder="Enter Full Name"
                value={fullname}
                onChange={(e) => {
                  setFullname(e.target.value);
                }}
                required
              />
            </Col>
            <Form.Control.Feedback type="invalid">
              Please provide a valid name.
            </Form.Control.Feedback>
          </Form.Group>
          <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
            <Form.Label column sm="2">
              Gender
            </Form.Label>
            <Col sm="10">
              <Form.Select
                aria-label="Default select example"
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                required
              >
                <option>Select option</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </Form.Select>
            </Col>
            <Form.Control.Feedback type="invalid">
              Please provide a gender.
            </Form.Control.Feedback>
          </Form.Group>
          <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
            <Form.Label column sm="2">
              Address
            </Form.Label>
            <Col sm="10">
              <Form.Control
                type="text"
                placeholder="Enter Address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                required
              />
            </Col>
            <Form.Control.Feedback type="invalid">
              Please provide a valid address.
            </Form.Control.Feedback>
          </Form.Group>

          <Form.Group
            as={Row}
            className="mb-3"
            controlId="formPlaintextPassword"
          >
            <Form.Label column sm="2">
              Mobile No.
            </Form.Label>
            <Col sm="10">
              <Form.Control
                type="Number"
                placeholder="Enter Mobile Number"
                value={mob}
                onChange={(e) => setMob(e.target.value)}
                required
              />
            </Col>
            <Form.Control.Feedback type="invalid">
              Please provide a valid mobile number.
            </Form.Control.Feedback>
          </Form.Group>
          <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
            <Form.Label column sm="2">
              Bank
            </Form.Label>
            <Col sm="10">
              <Form.Select
                aria-label="Default select example"
                value={bank}
                onChange={(e) => setBank(e.target.value)}
              >
                <option>Select option</option>
                <option value="Goldman Sachs">Goldman Sachs</option>
                <option value="Citigroup Inc">Citigroup Inc</option>
                <option value="Wells Fargo">Wells Fargo</option>
                <option value="Bank of America">Bank of America</option>
                <option value="HDFC">HDFC</option>
              </Form.Select>
            </Col>
            <Form.Control.Feedback type="invalid">
              Please provide a valid bank.
            </Form.Control.Feedback>
          </Form.Group>

          <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
            <Form.Label column sm="2">
              Type
            </Form.Label>
            <Col sm="10">
              <Form.Select
                aria-label="Default select example"
                value={type}
                onChange={(e) => setType(e.target.value)}
              >
                <option>Select option</option>
                <option value="Company">Company</option>
                <option value="Individual">Individual</option>
              </Form.Select>
            </Col>
            <Form.Control.Feedback type="invalid">
              Please provide a valid type.
            </Form.Control.Feedback>
          </Form.Group>

          <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
            <Form.Label column sm="2">
              Territory
            </Form.Label>
            <Col sm="10">
              <Form.Select
                aria-label="Default select example"
                value={territory}
                onChange={(e) => setTerritory(e.target.value)}
              >
                <option>Select option</option>
                <option value="East">East</option>
                <option value="West">West</option>
                <option value="North">North</option>
                <option value="South">South</option>
              </Form.Select>
            </Col>
            <Form.Control.Feedback type="invalid">
              Please provide a valid territory.
            </Form.Control.Feedback>
          </Form.Group>
          <Row>
            <Col></Col>
            <Col>
              {" "}
              <Button type="submit">Submit form</Button>
            </Col>
          </Row>
        </Form>
        <ToastContainer />
      </div>
    </>
  );
};

export default Clientform;
